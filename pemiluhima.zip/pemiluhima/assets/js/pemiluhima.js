// cari nama ketika nim diketik
$("#nim").keyup(function(){
  var nim=$(this).val();
  $.ajax({
  type: "POST",
  url: base_url+'daftar/read_nama/'+nim,
  data: csrf,
  success: function(response) {
    var hasil = JSON.parse(response);
    var namanya = 0;
    $.each(hasil, function(i, item) {
        namanya=hasil[i].nama;
    });
    if(namanya==0)
    {
    $("#nama").val("mencari...");
    }
    else
    {
    $("#nama").val(namanya);
    }
  }
});
});

// countdown
var countdown = new SV.Countdown('#countdown', {
  year: 2021,
  month: 09,
  day: 24,
  untilMessage: 'Voting Mencapai 50% Partisipan',
  endMessage: 'Voting Berakhir!!'
});

function preloader(){
	$("#preloader").animate({
			'opacity': '0'
		}, 600, function(){
			setTimeout(function(){
				$("#preloader").css("visibility", "hidden").fadeOut();
			}, 300);
		});
}
	



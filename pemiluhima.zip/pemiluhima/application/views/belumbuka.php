<br><br><br>
<center>
    <font color='red'><h1>Voting Belum Dibuka</h1></font>
</center>
<br><br><br>
<center>
    <font color='red'><h1>Vote sudah ditutup</h1></font>
</center>